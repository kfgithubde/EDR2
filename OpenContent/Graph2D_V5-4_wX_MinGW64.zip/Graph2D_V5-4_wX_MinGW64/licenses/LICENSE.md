## Graph2D and the LGPLv3 ##

Graph2D is free software; you can redistribute it and/or modify it under the terms of the Lesser GNU General Public License version 3 (LGPLv3) as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

See the GNU General Public License for more details. The LGPLv3 can be found in the `licenses` folder as 'lgpl-3.0.txt'.


## Rights holders of the code ##

Copyright (C): 

- 1988-2025 Dr. Klaus Friedewald